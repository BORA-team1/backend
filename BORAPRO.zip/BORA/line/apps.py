from django.apps import AppConfig


class LineConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "line"
